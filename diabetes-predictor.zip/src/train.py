
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.svm import SVC
from sklearn.metrics import classification_report, accuracy_score
from joblib import dump
from src.preprocess import load_data, clean_data, scale_features

def train_model(data_path):
    df = load_data(data_path)
    df = clean_data(df)

    X = df.drop("Outcome", axis=1)
    y = df["Outcome"]

    X_scaled, scaler = scale_features(X)
    X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.25, random_state=42)

    model = SVC(kernel='rbf', C=1.0, gamma='scale')
    model.fit(X_train, y_train)

    y_pred = model.predict(X_test)
    print("Accuracy:", accuracy_score(y_test, y_pred))
    print(classification_report(y_test, y_pred))

    dump(model, "models/svm_model.pkl")
    dump(scaler, "models/scaler.pkl")

if __name__ == "__main__":
    train_model("data/diabetes.csv")
