
from src.predict import predict_diabetes

def get_user_input():
    print("Enter the following details:")
    features = [
        "Pregnancies", "Glucose", "BloodPressure", "SkinThickness",
        "Insulin", "BMI", "DiabetesPedigreeFunction", "Age"
    ]
    values = []
    for feature in features:
        value = float(input(f"{feature}: "))
        values.append(value)
    return values

if __name__ == "__main__":
    user_input = get_user_input()
    result = predict_diabetes(user_input)
    if result == 1:
        print("⚠️  The person is likely Diabetic.")
    else:
        print("✅  The person is likely Non-Diabetic.")
