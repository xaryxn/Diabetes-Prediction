
import numpy as np
from joblib import load

def predict_diabetes(input_data):
    model = load("models/svm_model.pkl")
    scaler = load("models/scaler.pkl")

    input_array = np.array(input_data).reshape(1, -1)
    input_scaled = scaler.transform(input_array)

    prediction = model.predict(input_scaled)
    return prediction[0]
